package com.bladeofgod.flutteramapdrawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
